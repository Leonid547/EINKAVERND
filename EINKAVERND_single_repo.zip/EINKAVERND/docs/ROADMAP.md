# Roadmap

- **A**: MVP (stock Android): Guardian App + Orchestrator + basic FL.
- **B**: Runtime integrity: fs-verity enablement for artifacts; IMA/EVM policies; eBPF signals (requires OS integration).
- **C**: ROM integration for Pixel 10 once AOSP device/vendor/kernel/QPR sources are public; AVB signing and lock.
- **D**: Secure Aggregation + Differential Privacy + remote attestation dashboards.
