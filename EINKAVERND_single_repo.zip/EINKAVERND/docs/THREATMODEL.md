# Threat Model (summary)

## Assets
- Device integrity (boot state, vbmeta digest, patch level)
- Model updates (federated learning), server policy and trust roots
- On-device telemetry (aggregated features only)

## Adversaries
- Remote attacker with zero-click exploits
- Local attacker with physical access or malicious apps
- Supply-chain tampering of model updates or server policies

## Countermeasures
- **Key attestation** and **policy gating**
- **fs-verity** and prepared **IMA/EVM** for protected artifacts
- Optional **Secure Aggregation** + **Differential Privacy**
- Signed model artifacts and pinned trust roots
- Audit logging and challenge rotation
