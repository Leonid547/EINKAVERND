# Privacy Notes

- Opt-in only; no raw content or PII leaves the device.
- Only **aggregated features** and **model deltas** are transmitted.
- Support for **Secure Aggregation** and **Differential Privacy** is planned in the orchestrator.
- All uploads must include attestation and pass server-side policy checks.
