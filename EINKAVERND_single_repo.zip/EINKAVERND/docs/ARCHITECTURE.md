# Architecture (EINKAVERND)

## Overview

```
[ Guardian App ] --(attestation, features, FL updates)--> [ Orchestrator ]
          ^                                                 |
          |<--- policies, model, thresholds --------------- |
```

- **Attestation**: Guardian creates a StrongBox/KeyMint-backed key with a server challenge, exports the X.509 chain; server verifies and enforces **boot state**/patch policy.
- **Detector**: A small TFLite model (autoencoder/classifier) computes an **anomaly score** locally.
- **Federation**: Only devices in a **verified** state may submit updates; server aggregates and returns new model deltas.
- **Runtime integrity (ROM)**: fs-verity, IMA/EVM, and eBPF-based signals enrich detection (enabled once a custom OS build is available).
