package main

import (
	"flag"
	"log"
	"net/http"
	"os"

	httpapi "einkavernd/orchestrator/internal/http"
	"einkavernd/orchestrator/internal/policy"
)

func main() {
	addr := flag.String("addr", ":8080", "listen address")
	flag.Parse()

	pol := &policy.Policy{
		MinPatchLevel: getenv("EINKAVERND_MIN_PATCHLEVEL", "2025-01-01"),
		RequireLocked: getenvBool("EINKAVERND_REQUIRE_LOCKED_BOOTLOADER", true),
		AcceptDebug:   getenvBool("EINKAVERND_ACCEPT_DEBUG_BUILDS", false),
	}
	srv := httpapi.NewServer(pol)
	http.HandleFunc("/healthz", srv.Healthz)
	http.HandleFunc("/v1/attest/verify", srv.AttestVerify)
	http.HandleFunc("/v1/fl/update", srv.FLUpdate)

	log.Printf("EINKAVERND orchestrator listening on %s", *addr)
	log.Fatal(http.ListenAndServe(*addr, nil))
}

func getenv(k, def string) string {
	if v := os.Getenv(k); v != "" {
		return v
	}
	return def
}
func getenvBool(k string, def bool) bool {
	if v := os.Getenv(k); v != "" {
		if v == "1" || v == "true" || v == "TRUE" {
			return true
		}
		return false
	}
	return def
}
