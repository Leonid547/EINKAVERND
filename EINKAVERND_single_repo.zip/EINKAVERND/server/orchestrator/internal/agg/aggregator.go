package agg

import (
	"errors"
	"sync"
)

type MemoryAggregator struct {
	mu      sync.Mutex
	updates map[int]map[string][]float32 // round -> client -> weights
}

func NewMemoryAggregator() *MemoryAggregator {
	return &MemoryAggregator{updates: make(map[int]map[string][]float32)}
}

func (m *MemoryAggregator) AddUpdate(round int, client string, w []float32) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	if _, ok := m.updates[round]; !ok {
		m.updates[round] = make(map[string][]float32)
	}
	if _, exists := m.updates[round][client]; exists {
		return errors.New("duplicate update from client for this round")
	}
	m.updates[round][client] = w
	return nil
}

func (m *MemoryAggregator) AggregateIfReady(round int) ([]float32, bool) {
	m.mu.Lock()
	defer m.mu.Unlock()
	clients := m.updates[round]
	if len(clients) == 0 {
		return nil, false
	}
	var sum []float32
	var n int
	for _, w := range clients {
		if sum == nil {
			sum = make([]float32, len(w))
		}
		if len(w) != len(sum) {
			continue // skip malformed updates
		}
		for i := range w {
			sum[i] += w[i]
		}
		n++
	}
	if n == 0 {
		return nil, false
	}
	for i := range sum {
		sum[i] /= float32(n)
	}
	delete(m.updates, round)
	return sum, true
}
