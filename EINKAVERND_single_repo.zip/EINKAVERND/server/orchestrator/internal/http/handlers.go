package httpapi

import (
	"encoding/json"
	"net/http"
	"time"

	"einkavernd/orchestrator/internal/agg"
	"einkavernd/orchestrator/internal/attestation"
	"einkavernd/orchestrator/internal/policy"
)

type Server struct {
	agg    *agg.MemoryAggregator
	policy *policy.Policy
}

func NewServer(p *policy.Policy) *Server {
	return &Server{
		agg:    agg.NewMemoryAggregator(),
		policy: p,
	}
}

func (s *Server) Healthz(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusOK)
	_, _ = w.Write([]byte("ok"))
}

type AttestRequest struct {
	CertChainPEM []string `json:"cert_chain_pem"`
	ChallengeB64 string   `json:"challenge"`
}

type AttestResponse struct {
	OK         bool                   `json:"ok"`
	Reason     string                 `json:"reason,omitempty"`
	Parsed     map[string]interface{} `json:"parsed,omitempty"`
	VerifiedAt time.Time              `json:"verified_at"`
}

func (s *Server) AttestVerify(w http.ResponseWriter, r *http.Request) {
	var req AttestRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	result, parsed, err := attestation.VerifyChainAndChallenge(req.CertChainPEM, req.ChallengeB64, s.policy)
	resp := AttestResponse{OK: result, Parsed: parsed, VerifiedAt: time.Now()}
	if err != nil {
		resp.OK = false
		resp.Reason = err.Error()
	}
	_ = json.NewEncoder(w).Encode(resp)
}

type FLUpdate struct {
	ClientID  string    `json:"client_id"`
	Round     int       `json:"round"`
	Weights   []float32 `json:"weights"`
	Signature string    `json:"sig"`
}

type FLResponse struct {
	OK      bool      `json:"ok"`
	Round   int       `json:"round"`
	Weights []float32 `json:"weights,omitempty"`
}

func (s *Server) FLUpdate(w http.ResponseWriter, r *http.Request) {
	var up FLUpdate
	if err := json.NewDecoder(r.Body).Decode(&up); err != nil {
		http.Error(w, "bad request", http.StatusBadRequest)
		return
	}
	// TODO: verify signature bound to attested key (not implemented here).
	if err := s.agg.AddUpdate(up.Round, up.ClientID, up.Weights); err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	wts, ready := s.agg.AggregateIfReady(up.Round)
	resp := FLResponse{OK: true, Round: up.Round}
	if ready {
		resp.Weights = wts
	}
	_ = json.NewEncoder(w).Encode(resp)
}
