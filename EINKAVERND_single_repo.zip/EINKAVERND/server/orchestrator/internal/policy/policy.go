package policy

type Policy struct {
	MinPatchLevel string
	RequireLocked bool
	AcceptDebug   bool
}
