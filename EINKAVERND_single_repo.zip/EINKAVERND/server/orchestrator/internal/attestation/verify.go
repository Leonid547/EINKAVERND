package attestation

import (
	"crypto/x509"
	"encoding/pem"
	"errors"
	"fmt"
	"time"

	"einkavernd/orchestrator/internal/policy"
)

// VerifyChainAndChallenge parses a cert chain (leaf first) and checks the basic policy.
// NOTE: Placeholder: integrate a full Android Key Attestation verifier for production.
func VerifyChainAndChallenge(pems []string, challengeB64 string, pol *policy.Policy) (bool, map[string]interface{}, error) {
	if len(pems) == 0 {
		return false, nil, errors.New("empty chain")
	}
	chain := make([]*x509.Certificate, 0, len(pems))
	for _, s := range pems {
		block, _ := pem.Decode([]byte(s))
		if block == nil {
			return false, nil, errors.New("invalid pem")
		}
		c, err := x509.ParseCertificate(block.Bytes)
		if err != nil {
			return false, nil, err
		}
		chain = append(chain, c)
	}
	parsed := map[string]interface{}{
		"subject":    chain[0].Subject.String(),
		"not_before": chain[0].NotBefore.Format(time.RFC3339),
		"not_after":  chain[0].NotAfter.Format(time.RFC3339),
		"policy_hint": fmt.Sprintf("min_patchlevel=%s require_locked=%v",
			pol.MinPatchLevel, pol.RequireLocked),
	}
	// Soft-accept for PoC
	return true, parsed, nil
}
