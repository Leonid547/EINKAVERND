#!/usr/bin/env bash
set -euo pipefail
HOOKS_DIR="$(git rev-parse --show-toplevel)/tools/githooks"
mkdir -p .git/hooks
cp "$HOOKS_DIR/pre-push" .git/hooks/pre-push
chmod +x .git/hooks/pre-push
echo "Git hooks installed."
