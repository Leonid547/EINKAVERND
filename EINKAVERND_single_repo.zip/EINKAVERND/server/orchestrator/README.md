# EINKAVERND Orchestrator (quantumcore)

This repo contains the **Orchestrator** server for the EINKAVERND system (Icelandic for *private protection*).
It verifies **Android Key Attestation**, enforces **boot-state policies**, and coordinates **Federated Learning**.

> **Privacy-first defaults**: No personal endpoints or tokens are committed. Dev profile uses `localhost`/`10.0.2.2` only.

## Quickstart

```bash
go version          # Go 1.21+
cd cmd/orchestrator
go run . --addr :8080
```

### Environment variables
- `EINKAVERND_MIN_PATCHLEVEL=2025-10-01`
- `EINKAVERND_REQUIRE_LOCKED_BOOTLOADER=true`
- `EINKAVERND_ACCEPT_DEBUG_BUILDS=false`

Copy `.env.example` to `.env` and export it in your shell if needed.

## Endpoints
- `GET /healthz`
- `POST /v1/attest/verify` – JSON: `{ "cert_chain_pem": ["-----BEGIN..."], "challenge": "base64" }`
- `POST /v1/fl/update` – JSON: `{ "client_id": "...", "round": 1, "weights": [...], "sig": "..." }`

## Git safety
Run once to install hooks that prevent accidental publication of real endpoints/tokens:
```bash
tools/install-git-hooks.sh
```

## Repo layout
```
internal/
  agg/           # FedAvg (placeholder for Secure Aggregation + DP)
  attestation/   # Chain + challenge verification (stub; plug full verifier)
  http/          # Handlers
  policy/        # Policy struct
cmd/orchestrator # main()
configs/         # pixel10-dev env example
scripts/         # bootstrap helpers
tools/           # git hooks installer
```

---

**License**: Apache-2.0
