# EINKAVERND (single‑repo bundle)

This repository bundles all components needed to prototype the **EINKAVERND** system in one place,
without exposing any personal data or external endpoints by default.

## Layout
- `server/orchestrator/` — Go HTTP service: attestation verification (stub), Federated Learning aggregator.
- `apps/guardian-app/` — Android client (Kotlin + TensorFlow Lite) with `pixel10dev` flavor.
- `kernel/ebpf/` — eBPF probes (for future ROM integration).
- `docs/` — Architecture, Threat Model, Privacy, Roadmap.

## Privacy‑first defaults
- No personal domains or tokens are committed.
- Dev URLs are limited to `localhost` / `10.0.2.2`.
- Server repo includes a pre‑push hook to block accidental external endpoints/secrets.

## Quickstart (no CLI publishing required)
1. Create an empty repository in GitHub via the web UI (keep it **Private** for now).
2. **Unzip** this archive locally and then drag & drop the **contents** (folders & files) into the new repo page (`Add file` → `Upload files`).  
   > Tip: Upload the folders themselves (not the zip). GitHub will create directories accordingly.
3. Commit the upload. You're done.
4. Start the server locally and run the app in `pixel10dev` flavor against `http://10.0.2.2:8080`.

## Server quickstart
```bash
cd server/orchestrator/cmd/orchestrator
go run . --addr :8080
# Endpoints: /healthz, POST /v1/attest/verify, POST /v1/fl/update
```
> Module path has been sanitized to `einkavernd/orchestrator` to avoid leaking any identity.  
> Replace the attestation **stub** with a full Android Key Attestation verifier before production.

## App quickstart
- Open `apps/guardian-app` in Android Studio (AGP 8.5+, JDK 17).
- Select variant **`pixel10devDebug`**.
- Place your model at `app/src/pixel10dev/assets/guard_ae.tflite`.
- Run on emulator (uses `10.0.2.2`) or on device via tunnel/proxy if needed.

## Notes
- eBPF integration requires system/vendor privileges → intended for future ROM builds.
- Keep the repository **Private** until you complete a full security review.
