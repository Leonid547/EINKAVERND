#!/usr/bin/env bash
set -euo pipefail
REPO_URL="git@github.com:REPLACE-OWNER/Whormole.git"

git init
git checkout -b main
git add .
git commit -m "init: EINKAVERND Guardian App (Whormole) with pixel10-dev flavor"
git remote add origin "$REPO_URL"
echo "Local repo initialized. To push: git push -u origin main"
