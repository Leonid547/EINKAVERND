# EINKAVERND Guardian App (Whormole)

Android client for **EINKAVERND**: runs on-device anomaly detection and performs **KeyMint attestation**.
Includes a **`pixel10-dev`** product flavor that targets the local Orchestrator without exposing personal endpoints.

## Highlights
- Kotlin + TensorFlow Lite (drop your `guard_ae.tflite` under `app/src/pixel10dev/assets/`).
- Strict privacy defaults; no personal data is committed.
- Dev flavor allows cleartext to `10.0.2.2` only via a dedicated Network Security Config.

## Build
Open the project in **Android Studio (AGP 8.5+, JDK 17)** and select the **`pixel10devDebug`** variant.

## Config
- `BuildConfig.ORCHESTRATOR_URL` is defined per-flavor:
  - `pixel10dev`: `http://10.0.2.2:8080` (Android emulator to host)
  - `prod`: `"https://REPLACE-ME.invalid"` (placeholder, do not push real endpoints)
- Network security for `pixel10dev` lives in `res/xml/pixel10dev_network_security_config.xml`.
- **Do not** commit any personal IP/domain; hooks in the server repo will block pushes with non-allowlisted URLs.

**License**: Apache-2.0
