Production model placeholder. Do NOT commit a real model here.
