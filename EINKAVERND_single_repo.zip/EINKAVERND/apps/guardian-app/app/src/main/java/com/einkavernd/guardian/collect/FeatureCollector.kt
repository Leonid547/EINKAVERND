package com.einkavernd.guardian.collect

import android.app.ActivityManager
import android.content.Context
import android.net.TrafficStats
import kotlin.random.Random

class FeatureCollector(private val context: Context) {

    fun sampleVector(n: Int): FloatArray {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo().also { am.getMemoryInfo(it) }
        val rx = TrafficStats.getTotalRxBytes().toDouble()
        val tx = TrafficStats.getTotalTxBytes().toDouble()

        val v = FloatArray(n) { 0f }
        if (n > 0) v[0] = (mem.availMem / 1e9).toFloat()
        if (n > 1) v[1] = (rx / 1e9).toFloat()
        if (n > 2) v[2] = (tx / 1e9).toFloat()
        for (i in 3 until n) v[i] = Random.nextFloat() * 0.01f
        return v
    }
}
