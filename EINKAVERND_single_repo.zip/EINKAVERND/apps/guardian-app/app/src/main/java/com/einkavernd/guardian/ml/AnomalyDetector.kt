package com.einkavernd.guardian.ml

import android.content.Context
import org.tensorflow.lite.Interpreter
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.io.FileInputStream

class AnomalyDetector(private val context: Context) {
    private var tflite: Interpreter? = null
    private var inputSize = 128

    init {
        try {
            val mbb = loadModelFromAssets("guard_ae.tflite")
            tflite = Interpreter(mbb)
        } catch (e: Exception) {
            tflite = null
        }
    }

    fun isReady(): Boolean = tflite != null

    fun score(x: FloatArray): Float {
        if (tflite == null || x.size != inputSize) return 0.0f
        val input = arrayOf(x)
        val output = Array(1) { FloatArray(x.size) }
        tflite!!.run(input, output)
        var err = 0f
        for (i in x.indices) {
            val d = x[i] - output[0][i]
            err += d * d
        }
        return err
    }

    private fun loadModelFromAssets(fileName: String): MappedByteBuffer {
        val afd = context.assets.openFd(fileName)
        val fis = FileInputStream(afd.fileDescriptor)
        val fc: FileChannel = fis.channel
        return fc.map(FileChannel.MapMode.READ_ONLY, afd.startOffset, afd.length)
    }
}
