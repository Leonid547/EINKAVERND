package com.einkavernd.guardian

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.einkavernd.guardian.attestation.Attestor
import com.einkavernd.guardian.collect.FeatureCollector
import com.einkavernd.guardian.ml.AnomalyDetector
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val tv = TextView(this)
        tv.text = "EINKAVERND Guardian – pixel10-dev profile active?"
        setContentView(tv)

        lifecycleScope.launch {
            val attestor = Attestor(this@MainActivity)
            val features = FeatureCollector(this@MainActivity)
            val detector = AnomalyDetector(this@MainActivity)

            // Normally, request a challenge from ORCHESTRATOR_URL
            val chainPem = withContext(Dispatchers.IO) { attestor.generateAndExport("demo-challenge".toByteArray()) }
            val x = withContext(Dispatchers.IO) { features.sampleVector(128) }
            val score = detector.score(x)

            tv.append("\nAttestation certs: ${chainPem.size}")
            tv.append("\nAnomaly score: %.5f".format(score))
            tv.append("\nOrchestrator: " + BuildConfig.ORCHESTRATOR_URL)
        }
    }
}
