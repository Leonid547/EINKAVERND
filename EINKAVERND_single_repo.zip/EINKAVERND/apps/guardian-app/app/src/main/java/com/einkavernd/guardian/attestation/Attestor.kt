package com.einkavernd.guardian.attestation

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.cert.Certificate
import java.util.Base64

class Attestor(private val context: Context) {
    private val alias = "einkavernd_attested_key"

    fun generateAndExport(challenge: ByteArray): List<String> {
        val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
            .setAttestationChallenge(challenge)
            .setDigests(KeyProperties.DIGEST_SHA256)
            .setIsStrongBoxBacked(true) // if available
            .build()

        kpg.initialize(spec)
        kpg.generateKeyPair()

        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val chain: Array<Certificate> = ks.getCertificateChain(alias)
        return chain.map { cert ->
            val b64 = Base64.getEncoder().encodeToString(cert.encoded)
            "-----BEGIN CERTIFICATE-----\n$b64\n-----END CERTIFICATE-----"
        }
    }
}
