Place dev model here as guard_ae.tflite
