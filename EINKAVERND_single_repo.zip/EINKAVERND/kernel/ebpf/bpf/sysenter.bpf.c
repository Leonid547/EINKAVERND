// SPDX-License-Identifier: GPL-2.0
#include <vmlinux.h>
#include <bpf/bpf_helpers.h>
#include <bpf/bpf_tracing.h>

struct event_t { u32 pid; u32 syscall_id; };

struct {
  __uint(type, BPF_MAP_TYPE_RINGBUF);
  __uint(max_entries, 1 << 24);
} events SEC(".maps");

SEC("tracepoint/raw_syscalls/sys_enter")
int sys_enter(struct trace_event_raw_sys_enter *ctx) {
  struct event_t *e = bpf_ringbuf_reserve(&events, sizeof(*e), 0);
  if (!e) return 0;
  e->pid = bpf_get_current_pid_tgid() >> 32;
  e->syscall_id = ctx->id;
  bpf_ringbuf_submit(e, 0);
  return 0;
}

char LICENSE[] SEC("license") = "GPL";
