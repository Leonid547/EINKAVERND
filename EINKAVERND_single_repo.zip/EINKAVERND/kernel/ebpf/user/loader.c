// Placeholder user-space loader (requires libbpf).
// On stock Android this requires privileged context and is not suitable for apps.
#include <stdio.h>
int main() {
  printf("EINKAVERND eBPF loader stub. Integrate in ROM build.\n");
  return 0;
}
