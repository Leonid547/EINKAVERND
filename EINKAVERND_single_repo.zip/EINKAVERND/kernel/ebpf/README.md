# eBPF Probes (ROM Integration)

This directory contains a minimal CO‑RE eBPF program (`bpf/sysenter.bpf.c`) and a user loader stub.
On stock Android, attaching privileged eBPF requires a system/vendor context. Integrate this into
the OS build later and feed events into the Guardian service.

Build steps will depend on your ROM toolchain (NDK + libbpf or bpftool integration).
